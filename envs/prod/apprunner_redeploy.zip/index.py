import os, json, boto3

APP_RUNNER_ARN = os.environ["APP_RUNNER_ARN"]
client = boto3.client("apprunner")

def handler(event, context):
    # event is the rotation success CloudTrail event; we don't need to parse it
    try:
        resp = client.start_deployment(ServiceArn=APP_RUNNER_ARN)
        return {
            "statusCode": 200,
            "body": json.dumps({"operationId": resp.get("OperationId")})
        }
    except Exception as e:
        print(f"[ERROR] {e}")
        raise
